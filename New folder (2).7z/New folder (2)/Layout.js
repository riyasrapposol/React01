import React, { Component } from 'react';
import { Container } from 'reactstrap';
import { NavMenu } from './NavMenu';
import styled from 'styled-components';
const GridWrapper = styled.div`
  display: absolute;
  grid-gap: 10px;
  margin-top: 0.5em;
  margin-left: 12em;
//  margin-right: 6em;
 // grid-template-columns: repeat(12, 1fr);
 // grid-auto-rows: minmax(25px, auto);
`;
export class Layout extends Component {
  static displayName = Layout.name;

  render () {
    return (
      <GridWrapper>
          <Container>
          {this.props.children}
        </Container>
        </GridWrapper>
    );
  }
}
